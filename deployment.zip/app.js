"use strict";
var port = process.env.PORT || 3000, express = require("express");
const app = express();
app.get("/", (req, res) => {
    res.send("HELLO");
});
app.listen(3000, () => {
    console.log('Server running at http://127.0.0.1:' + port + '/');
});
//# sourceMappingURL=index.js.map